<?php

return [
    'ApplicationID' => '3766def2c9f0f87718a73653b67867fbf845ca7712db8c7bea18ce3d5ca81dd0',
];
