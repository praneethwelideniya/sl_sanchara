<div role="tabpanel" class="tab-pane" id="activity_calander">
    <div class="section">    
        <div class="container">
            <div class="row">
                <div class="col-md-10 col-md-offset-1">
                    <?php $__currentLoopData = $calender; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $activities): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="thinn-event-list mb-30">
                           <figure>
                            <div>
                                    <strong class="font-50"><?php echo e(explode('-', $key, 3)[0]); ?></strong>
                                    <br>
                                    <strong class="font-50"><?php echo e(explode('-', $key, 3)[1]); ?> /</strong>
                                    
                                    <strong class="font-50"><?php echo e(explode('-', $key, 3)[2]); ?></strong>
                            </div>
                        </figure> 
                        <div class="text">
                            <?php $__currentLoopData = $activities; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key_0=>$activity): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <ul class="blog-meta event-meta">
                                <li>
                                    <i class="icon-calendar5"></i>
                                    <span><?php echo e($activity->start->format('h:i A').'--'.$activity->end->format('h:i A')); ?>,
                                    <?php if($activity->activity_type=='transport' and $activity->currentActivity!=null): ?>
                                        Travel from <?php echo e($activity->currentActivity->start_location); ?> to <?php echo e($activity->currentActivity->end_location); ?> by <?php echo e($activity->currentActivity->transportType->name); ?>

                                    <?php elseif($activity->activity_type=='accommodate' and $activity->currentActivity!=null): ?>
                                        Accommodate at <?php echo e($activity->currentActivity->accommodation_name); ?>

                                    <?php elseif($activity->activity_type=='meal' and $activity->currentActivity!=null): ?>
                                            Have a meal at <?php echo e($activity->currentActivity->place_name); ?>

                                    <?php elseif($activity->currentActivity!=null): ?>
                                            Travel to <?php echo e($activity->currentActivity->place_name); ?>

                                    <?php endif; ?>    
                                    </span>
                                </li>
                            </ul>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    </div>    
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>

        </div><!-- / Container -->
    </div>  
</div>  
