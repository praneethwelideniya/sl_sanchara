<div class="row">
    <div class="col-md-4">
        <div class="form-group">
            <label>Transpotation Type</label>
            <select class="form-controll" id="sel1" name="transpotation_type_id" >
                <?php $__currentLoopData = $transpotation_types; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $transport): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($transport->id); ?>"
                        <?php if($activity->transpotation_type_id===$transport->id): ?>
                            selected="selected"
                        <?php endif; ?>
                    ><?php echo e($transport->name); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>               
            </select>
        </div>
    </div> 
    <div class="col-md-4">
        <div class="form-group">
            <label>Start Location:</label>
            <input type="text" id="budget" class="form-controll" name="start_location" placeholder="Start Location" value="<?php echo e($activity!=null?$activity->start_location : ''); ?>">
        </div>
    </div>
    <div class="col-md-4">
        <div class="form-group">
            <label>End Location:</label>
            <input type="text" id="budget" class="form-controll" name="end_location" placeholder="End Location" value="<?php echo e($activity!=null?$activity->end_location : ''); ?>">
        </div>
    </div>   
</div>