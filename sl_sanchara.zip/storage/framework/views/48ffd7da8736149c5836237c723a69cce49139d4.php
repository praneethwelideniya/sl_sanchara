<div role="tabpanel" class="tab-pane active" id="trip_users">
	<div class="section">
        <div class="container">
            <div class="row">
                <div id="traveller">
                	<input type="hidden" :value="trip_id=<?php echo e($id); ?>">
                    <?php echo $__env->make('traveller._traveller_list', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>;
                </div>
            </div>
        </div><!-- / Container -->
    </div><!-- /Blog Grid Section -->
 </div>