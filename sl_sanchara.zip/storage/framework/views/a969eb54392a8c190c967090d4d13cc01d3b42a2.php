<?php $__env->startSection('content'); ?>            
    <div class="main-contant">    
        <div class="section">
            <div class="container">
            	<h2>Articles</h2>
                <div class="row">
                	<?php $__currentLoopData = $articles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $article): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-md-4 col-sm-6">
                        <!-- Blog Thumb Start -->
                        <div class="thinn-blog-thumb thinn-blog-grid mb-30">
                            <figure>
                                <img src="<?php echo e(asset('/users').'/'.$article->user->id.'/article/'.$article->images()->wherePivot('image_type','cover')->first()['src']); ?>" alt="profile Pic"/ height="220"> 
                            </figure>
                            <div class="text">
                                <div class="date-box-holder">
                                    <div class="title-holder">
                                        <h5 class="title font-18"><a href="blog-detail.html"><?php echo e($article->heading); ?></a></h5>
                                        <ul class="blog-meta">
                                            <li>
                                                <i class="icon-comment"></i>
                                                <a href="#"><?php echo e($article->comment_count); ?></a>
                                            </li>
                                            <li>
                                                <i class="icon-eye"></i>
                                                <a href="#"><?php echo e($article->hit_count); ?></a>
                                            </li>
                                        </ul>
                                    </div>
                                    <div class="date-box">
                                        <strong class="font-50"><?php echo e($article->published_at->format('d')); ?></strong>
                                        <strong class="font-18"><?php echo e($article->published_at->format('M')); ?></strong>
                                        <strong class="font-15"><?php echo e($article->published_at->format('Y')); ?></strong>
                                    </div>
                                </div>
                                <p><?php echo str_limit($article->content, $limit = 50, $end = '...'); ?></p>
                                <a class="btn btn-2" href="<?php echo e(route('get-article',$article->id)); ?>">View detail</a>
                            </div>
                        </div>
                        <!-- /Blog Thumb End -->
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-md-12">
                        <!-- Pagination Start-->
                        <div class="thinn-pagination text-center">
                            <?php echo e($articles->links()); ?>

                        </div>
                        <!-- Pagination End-->
                    </div>
                </div>
            </div><!-- / Container -->
        </div><!-- /Blog Grid Section -->
    </div>
<?php $__env->stopSection(); ?>        
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>