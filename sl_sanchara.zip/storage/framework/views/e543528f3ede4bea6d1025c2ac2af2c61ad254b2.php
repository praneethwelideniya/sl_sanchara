<?php $__env->startSection('styles'); ?>
<link href="<?php echo e(mix('/css/app.css')); ?>" rel="stylesheet">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?> 
            <div class="main-contant">
                <section class="pb-0">
                    <!-- SECTION HEADING START -->
                    <!-- SECTION HEADING END -->
                    <div class="gray-bg about-caption d-flex align-items-center">
                        <div class="col-md-10 col-sm-10 col-md-offset-1">
                            <!-- MAIN PREVIEW START -->
                            <div class="bg-slider arrow-2">
                                <?php $__currentLoopData = $article->images()->wherePivot('image_type','cover')->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="thumb-landscape bg-thumb">
                                    <img src="<?php echo e(asset('/users').'/'.'article/'.$image->src); ?>" alt="">
                                    <div class=" banner-caption-wrapper text-center">
                                        <div class="container">
                                            <div class="banner-caption caption-style-1">
                                                <h6 class="title small-title"><?php echo e($article->heading); ?></h6>
                                                <div class="clear"></div>
                                                <h4 data-animation="fadeInUp" data-delay="0.3s" class="title title-bigger"><?php echo e($article->heading); ?></h4>
                                                <h5 data-animation="fadeInUp" data-delay="0.3s" class="title title-medium"><?php echo e($article->heading); ?></h5>
                                                <ul class="blog-meta">
                                                    <li>
                                                        <i class="icon-calendar5"></i>
                                                        <a href="#"><?php echo e($article->published_at->format('d M')); ?></a>
                                                    </li>
                                                    <li>
                                                        <i class="icon-user"></i>
                                                        <a href="#"><?php echo e($article->user->name); ?></a>
                                                    </li>
                                                    <li>
                                                        <i class="icon-tag6"></i>
                                                        <?php $__currentLoopData = $article->keywords; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $keyword): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <a href="#"><?php echo e($keyword->name); ?></a>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    </li>
                                                </ul>
                                            </div>
                                        </div>
                                    </div>                                   
                                </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                
                            </div>
                            <!-- MAIN PREVIEW END -->
                        </div>
                    </div>
                </section> 
                <div class="section">
                    <div class="container">
                        <div class="row">
                            <div class="col-md-10">
                                <div class="tour-detail-section">
                                    <!-- TOUR TEXT DETAIL HOLDER -->
                                    <div class="text">
                                        <!-- Tab Wrap Start -->
                                        <div class="tours-tabs">
                                            <!-- Nav tabs -->
                                            <ul class="nav nav-tabs theme-tab th-bg" role="tablist">
                                                <li role="presentation" class="active"><a href="#detail" aria-controls="detail" role="tab" data-toggle="tab">Detail</a></li>
                                                <li role="presentation"><a href="#photos" aria-controls="photos" role="tab" data-toggle="tab">Photos</a></li>
                                                <?php if(Auth::check() and Auth::user()->id==$article->user->id): ?>
                                                <li role="presentation"><a href="<?php echo e(route('edit-article',$article->id)); ?>" >Edit</a></li>
                                                <?php endif; ?>
                                            </ul>
                                            <!-- Tab panes -->
                                            <div class="tab-content">
                                                <div role="tabpanel" class="tab-pane active" id="detail">
                                                    <div class="theme-tab-content">
                                                        <h4 class="section-title font-26">Tour Details</h4>
                                                        <div class="article-body"><?php echo $article->content; ?></div>
                                                        <!-- List Row Start -->
                                                    
                                                        </div>

                                                </div>
                                                <div role="tabpanel" class="tab-pane" id="photos">
                                                <div class="theme-tab-content">
                                                      <?php echo $__env->make('traveller._article_images', ['article' => $article, 'edit' => false], \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>  
                                                </div>
                                            </div>
                                            </div>
                                        </div>
                                        <!-- Tab Wrap End -->
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div><!-- / Container -->
                </div><!-- /Blog Grid Section -->
                <!-- News Letter Item Start -->
                <!-- / News Letter Item End -->
            </div><!-- /Main Contant End -->
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
<script src="<?php echo e(mix('js/user_profile.js')); ?>" type="application/javascript"></script>
<script type="text/javascript">
    $(document).ready(function(){
       $('#edit_content').click(function(){
            $("#idshow").hide();
            $("#idedit").show();
        });            
    }); 
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>