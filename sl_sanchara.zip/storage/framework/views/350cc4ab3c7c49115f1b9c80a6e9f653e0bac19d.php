<?php $__env->startSection('content'); ?>
            <div class="main-contant"> 
                <div class="section">
                    <div class="container">
                        <div class="row">
                            <div class="col-md-8 col-md-offset-2">
                                <div class="contact-form">
                                    <h2 class="section-title font-26 mb-22">Registration Form</h2>
                                    <form id="contact-form" method="POST" action="<?php echo e(route('register')); ?>">
                                     <?php echo e(csrf_field()); ?>    
                                        <div class="row">
                                            <div class="col-md-10 col-sm-10">

                                                <div class="form-group<?php echo e($errors->has('name') ? ' has-error' : ''); ?>">
                                                    <h5 class="font-10 mb-10">NAME:</h5>
                                                    <input type="text" value="" data-msg-required="Please enter your name" maxlength="100" class="form-control " name="name" id="name" placeholder="Name *" value="<?php echo e(old('name')); ?>" required>
                                                    <div class="col-md-6">

                                                        <?php if($errors->has('name')): ?>
                                                            <span class="help-block">
                                                                <strong><?php echo e($errors->first('name')); ?></strong>
                                                            </span>
                                                        <?php endif; ?>
                                                    </div>
                                                </div>
                                                <div class="form-group<?php echo e($errors->has('email') ? ' has-error' : ''); ?>">
                                                    <h5 class="font-10 mb-10">Email:</h5>
                                                    <input type="email" value="" data-msg-required="Please enter your email address" data-msg-email="Please enter a valid email address" maxlength="80" class="form-control " name="email" id="email" placeholder="E-mail *" value="<?php echo e(old('email')); ?>" required>
                                                    <div class="col-md-6">

                                                        <?php if($errors->has('email')): ?>
                                                            <span class="help-block">
                                                                <strong><?php echo e($errors->first('email')); ?></strong>
                                                            </span>
                                                        <?php endif; ?>
                                                    </div>
                                                </div>
                                                <div class="form-group<?php echo e($errors->has('password') ? ' has-error' : ''); ?>">
                                                    <h5 class="font-10 mb-10">Password:</h5>
                                                    <input type="password" data-msg-required="Please enter your email address" data-msg-email="Please enter a valid email address" maxlength="100" class="form-control " name="password" id="password" placeholder="Password" required>
                                                    <div class="col-md-6">

                                                        <?php if($errors->has('password')): ?>
                                                            <span class="help-block">
                                                                <strong><?php echo e($errors->first('password')); ?></strong>
                                                            </span>
                                                        <?php endif; ?>
                                                    </div>
                                                </div>
                                                <div class="form-group<?php echo e($errors->has('password') ? ' has-error' : ''); ?>">
                                                    <h5 class="font-10 mb-10">Password Confimation:</h5>
                                                    <input type="password" value="" data-msg-required="Please enter your email address" data-msg-email="Please enter a valid email address" maxlength="100" class="form-control " name="password_confirmation" id="password-conf" placeholder="Password" required>
                                                </div>
                                            </div>
                                            <div class="col-md-12">
                                                <input class="btn" type="submit" value="submit" data-loading-text="Loading...">
                                            </div>
                                            <!--Input Field End-->
                                            <div class="alert alert-success hidden animated pulse" id="contactSuccess">
                                                Thanks, your message has been sent to us.
                                            </div>
                                            <div class="alert alert-danger hidden animated shake" id="contactError">
                                                <strong>Error!</strong> There was an error sending your message.
                                            </div>
                                        </div>
                                    </form>
                                </div>
                            </div>
                        </div>
                        
                    </div><!-- / Container -->
                </div><!-- /Blog Grid Section -->
            </div>
                <!-- News Letter Item Start -->
                <?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>