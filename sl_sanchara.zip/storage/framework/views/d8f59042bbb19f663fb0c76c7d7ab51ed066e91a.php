<div role="tabpanel" class="tab-pane active" id="activities">
                <div class="section">
                    <div class="container">
                        <div class="row">
                            <div class="col-md-12">
                                <?php $__currentLoopData = $trip->activities; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $activity): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <!-- Blog Thumb Start -->
                                <div class="thinn-event-list mb-30">
                                    <figure>
                                        <img src="<?php echo e(asset('/trip').'/'.$activity->activity_type.'.jpg'); ?>" alt=""> 
                                    </figure>
                                    <div class="text">
                                        <h5 class="title font-18"><?php echo e($key+1); ?></h5>
                                        <ul class="blog-meta event-meta">
                                            <li>
                                                <i class="icon-calendar5"></i>
                                                <span><?php echo e($activity->start->format('d M Y H:i:s')); ?></span>
                                                ---
                                                <span><?php echo e($activity->end->format('d M Y H:i:s')); ?></span>
                                            </li>
                                            <li>
                                                <i class="icon-pricetags"></i>
                                                <span>Rs.<?php echo e($activity->cost); ?></span>
                                            </li>
                                            <li>
                                                <i class="icon-pricetags"></i>
                                                <span><?php echo e($activity->activity_type); ?></span>
                                            </li>
                                        </ul>
                                        <p><?php echo e($activity->description); ?></p>
                                        <p>
                                            <?php if($activity->currentActivity!=null): ?>
                                            <?php if($activity->activity_type==='transport'): ?>
                                            <h5 class="title font-18"><a href="#"><i class="icon-map-pin2"></i></a> Start Location:<?php echo e($activity->currentActivity->start_location); ?> </h5>
                                            <h5 class="title font-18"><a href="#"><i class="icon-map-pin2"></a></i> End Location:<?php echo e($activity->currentActivity->end_location); ?></h5>
                                            <h5 class="title font-18">Travel By:<?php echo e($activity->currentActivity->transportType->name); ?></h5>
                                            <?php elseif($activity->activity_type==='accommodate'): ?>
                                            <h5 class="title font-18"><a href="#"><i class="icon-map-pin2"></i></a> Location:<?php echo e($activity->currentActivity->accommodation_name); ?> </h5>
                                            <?php elseif($activity->activity_type==='meal'): ?>
                                            <?php else: ?>
                                            <h5 class="title font-18"><a href="#"><i class="icon-map-pin2"></i></a>Location:<?php echo e($activity->currentActivity->place_name); ?> </h5>
                                            <?php endif; ?>
                                            <?php endif; ?>
                                        </p>
                                        <a class="btn btn-2" href="#">Join Event</a>
                                    </div>
                                </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                        </div>
                    </div><!-- / Container -->
                </div><!-- /Blog Grid Section -->
</dev></div>