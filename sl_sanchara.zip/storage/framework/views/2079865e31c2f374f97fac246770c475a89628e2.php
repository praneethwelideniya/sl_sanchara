<?php $__env->startSection('styles'); ?>
<link href="<?php echo e(mix('/css/app.css')); ?>" rel="stylesheet">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
            
            <div id="sl_sanchara">
                <?php echo $__env->make('traveller._profile_bar', ['user' => $user,'public'=>$public, 'complete'=>0], \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                <?php echo $__env->make('traveller._upload_modal', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            </div>
            <div class="main-contant">
                <div id="blogs" user_id="<?php echo e($user->id); ?>">  
                <?php echo $__env->make('blogs._blogs', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?> 
            </div>
            <div class="section">
                <section class="pd-0 gallery-slider-wrap">

                    <div class="row ">
                        
                        <div class="col-md-10 col-sm-12">
                            <ul class="gallery-slider arrow-2">
                                <?php $__currentLoopData = $user->images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li class="col-md-3 col-sm-4">
                                    <!-- GALLERY THUMB START -->
                                    <div class="gallery-thumb th-bg">
                                        <figure>
                                            <img src="<?php echo e(asset('/users').'/'.$image->img_type.'/'.$image->src); ?>" alt="" height="300" />
                                            <figcaption>
                                                <a href="#"><?php echo e($image->caption); ?></a>
                                                <ul>
                                                    <li>
                                                        <a href="#other_image" data-toggle="modal" data-target="#deleteModal" ><i class="icon-recycle"></i></a>
                                                    </li>    
                                                </ul>
                                            </figcaption>
                                        </figure>
                                    </div>
                                    <!-- GALLERY THUMB END -->
                                </li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        </div>
                        <div class="col-md-2 hidden-sm hidden-xs">
                                                <!-- SECTION HEADING START -->
                            <div class="section-heading text-center mb-0">
                                <h3 class="title">Photo Gallery</h3>
                                <h5 class="title" id="other_pic"><i class="icon-camera"></i></h5>
                            </div>
                            <!-- SECTION HEADING END -->
                        </div>
                    </div>
                </section> 
                </div>
            </div><!-- /Main Contant End -->
                    <!-- Modal -->
        
        <div id="deleteModal" class="modal fade" role="dialog">
          <div class="modal-dialog">

            <!-- Modal content-->
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal">&times;</button>
                    <h4 class="modal-title">File upload form</h4>
                </div>
                <div class="modal-body">
                    <!-- Form -->
                    <form method='post' action="<?php echo e(route('delete_pic')); ?>">
                        <?php echo csrf_field(); ?>
                        <input type="hidden" id="del-user-id" name="id" >
                        <button type="submit" class="btn btn-primary btn-xs">Delete</button>
                    </form>

                    <!-- Preview-->
                    <div id='preview'></div>
                </div>
                
            </div>

          </div>
        </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
<script src="<?php echo e(mix('js/user_profile.js')); ?>" type="application/javascript"></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>