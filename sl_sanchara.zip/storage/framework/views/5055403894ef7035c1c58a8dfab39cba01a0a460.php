<?php $__env->startSection('styles'); ?>
<link href="<?php echo e(mix('/css/app.css')); ?>" rel="stylesheet">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
            <div class="main-contant"> 
                <div class="section">
                    <div class="container">
                        <div class="row">
                            <div id="traveller">
                                <?php echo $__env->make('traveller._traveller_list', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>;
                            </div>
                        </div>
                    </div><!-- / Container -->
                </div><!-- /Blog Grid Section -->
                <!-- News Letter Item Start -->
                <!-- / News Letter Item End -->
            </div><!-- /Main Contant End -->
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
<script src="<?php echo e(mix('js/user_profile.js')); ?>" type="application/javascript"></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>