<div class="row">  
    <div class="col-md-8">
        <div class="form-group">
            <label>Place:</label>
            <input type="text" id="cost" class="form-controll" name="accommodation_name" placeholder="Place" value="<?php echo e($activity!=null?$activity->accommodation_name:''); ?>">
        </div>
    </div>
</div>