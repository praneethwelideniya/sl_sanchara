<div class="row">
  
    <div class="col-md-8">
        <div class="form-group">
            <label>Place:</label>
            <input type="text" id="cost" class="form-controll" name="place_name" placeholder="Place" value="{{$activity!=null?$activity->place_name:''}}">
        </div>
    </div>
</div>