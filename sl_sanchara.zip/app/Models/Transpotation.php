<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Transpotation extends Model
{
    protected $table = 'transpotation_types';
}
