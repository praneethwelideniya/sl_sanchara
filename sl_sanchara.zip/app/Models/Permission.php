<?php

namespace App\Models;



class Permission 
{
    //
}
